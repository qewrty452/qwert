package com.lanterns.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 12, 11)
    private val panel = Color.rgb(12, 25, 22)
    private val accent = Color.rgb(113, 151, 119)
    private val pale = Color.rgb(210, 220, 210)
    private val dim = Color.rgb(135, 154, 139)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildHome()
    }

    override fun onResume() {
        super.onResume()
        // Rebuild the app list after returning from another app.
        if (isFinishing.not()) buildHome()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(12))
            setBackgroundColor(bg)
        }
        val heading = TextView(this).apply {
            text = "L A N T E R N S"
            textSize = 23f
            letterSpacing = 0.12f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(pale)
        }
        val year = TextView(this).apply {
            text = "2026  /  DARK GREEN EDITION"
            textSize = 10f
            letterSpacing = 0.16f
            setTextColor(accent)
            setPadding(0, dp(5), 0, dp(22))
        }
        val divider = View(this).apply { setBackgroundColor(Color.rgb(35, 57, 46)) }
        root.addView(heading)
        root.addView(year)
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))

        val scroll = ScrollView(this).apply { fillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, dp(18))
        }
        val label = TextView(this).apply {
            text = "ПРИЛОЖЕНИЯ"
            textSize = 10f
            letterSpacing = 0.18f
            setTextColor(dim)
            setPadding(dp(2), 0, 0, dp(12))
        }
        content.addView(label)
        val grid = GridLayout(this).apply {
            columnCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        val apps = loadLaunchableApps()
        if (apps.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Не удалось загрузить список приложений. Перезапусти лаунчер."
                textSize = 14f
                setTextColor(pale)
            })
        } else {
            apps.forEach { info -> grid.addView(makeAppTile(info)) }
            content.addView(grid)
        }
        val footer = TextView(this).apply {
            text = "Текущие обои сохраняются  ·  Нажми приложение, чтобы открыть"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(dim)
            setPadding(0, dp(26), 0, dp(8))
        }
        content.addView(footer)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadLaunchableApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun makeAppTile(info: ResolveInfo): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(10), dp(3), dp(10))
            background = rounded(panel, dp(14))
            isClickable = true
            isFocusable = true
            contentDescription = info.loadLabel(packageManager).toString()
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launch != null) startActivity(launch)
            }
        }
        val icon = ImageView(this).apply {
            setImageDrawable(info.loadIcon(packageManager))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        tile.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
        val name = TextView(this).apply {
            text = info.loadLabel(packageManager).toString()
            textSize = 10.5f
            gravity = Gravity.CENTER
            setTextColor(pale)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(7), 0, 0)
        }
        tile.addView(name, LinearLayout.LayoutParams(-1, dp(34)))
        val params = GridLayout.LayoutParams().apply {
            width = 0
            height = GridLayout.LayoutParams.WRAP_CONTENT
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(3), dp(3), dp(3), dp(7))
        }
        tile.layoutParams = params
        return tile
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(dp(1), Color.rgb(25, 42, 34))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
